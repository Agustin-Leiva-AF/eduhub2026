#!/usr/bin/env python3
"""
Ejemplo de calibración del Analista Researcher sobre SPY (semanal ajustado, Alpha Vantage).
1) Indicadores técnicos (EMA 20/50/200, RSI 14, Bollinger 20,2) contra la referencia de Alpha Vantage.
2) GJR-GARCH-t + Monte Carlo, y su calibración fuera de muestra (VaR, cobertura de bandas, PIT).
Genera 3 gráficos PNG y un resumen JSON.
"""
import io
import json
import sys
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")
import logging; logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
import os
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, "..", "scripts"))
import montecarlo_gjr as mg  # noqa: E402

OUT = AQUI
PRECIOS = os.path.join(AQUI, "spy_weekly.csv")                # TIME_SERIES_WEEKLY_ADJUSTED de Alpha Vantage
BB_FILE = os.path.join(AQUI, "bbands_alpha_vantage.csv")      # BBANDS semanal (20, 2) de Alpha Vantage
PPA = 52  # períodos por año (semanal)

# ---- estilo (paleta validada: blue, orange, aqua, yellow; texto en tinta, no en color de serie)
C = {"blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a", "yellow": "#eda100",
     "red": "#d03b3b", "ink": "#0b0b0b", "ink2": "#52514e", "grid": "#e4e3df", "surf": "#fcfcfb",
     "band": "#cde2fb"}
plt.rcParams.update({
    "font.family": ["Aptos", "DejaVu Sans"], "font.size": 9.5, "axes.edgecolor": C["grid"],
    "axes.labelcolor": C["ink2"], "xtick.color": C["ink2"], "ytick.color": C["ink2"],
    "axes.grid": True, "grid.color": C["grid"], "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "figure.facecolor": C["surf"], "axes.facecolor": C["surf"],
    "axes.titleweight": "bold", "axes.titlesize": 11, "axes.titlelocation": "left",
    "axes.titlecolor": C["ink"], "lines.linewidth": 1.6, "legend.frameon": False,
})
FUENTE = "Fuente: Alpha Vantage (SPY semanal, precio ajustado, 1999–2026). Cálculos propios. ORCA"


def es(x, d=1):
    """Número con coma decimal y punto de miles."""
    return f"{x:,.{d}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def pct(x, d=1, signo=False):
    return (("+" if x > 0 else "−" if x < 0 else "") if signo else "") + es(abs(x) * 100 if signo else x * 100, d) + "%"


USD = matplotlib.ticker.FuncFormatter(lambda y, _: "$" + es(y, 0))


def pie(fig):
    fig.text(0.01, 0.005, FUENTE, fontsize=7.5, color=C["ink2"], ha="left", va="bottom")


# ================================================================ datos
px = pd.read_csv(PRECIOS, parse_dates=["timestamp"]).set_index("timestamp").sort_index()
close = px["adjusted close"].astype(float)


# ================================================================ indicadores (convención TA-Lib)
def ema_talib(x, n):
    """EMA sembrada con la media simple de los primeros n valores (como TA-Lib / Alpha Vantage)."""
    v = x.values.astype(float); out = np.full(len(v), np.nan); k = 2 / (n + 1)
    out[n - 1] = v[:n].mean()
    for i in range(n, len(v)):
        out[i] = v[i] * k + out[i - 1] * (1 - k)
    return pd.Series(out, index=x.index)


def rsi_wilder(x, n=14):
    d = x.diff().values; g = np.clip(d, 0, None); l = np.clip(-d, 0, None)
    out = np.full(len(x), np.nan)
    ag, al = g[1:n + 1].mean(), l[1:n + 1].mean()
    out[n] = 100 - 100 / (1 + ag / al)
    for i in range(n + 1, len(x)):
        ag = (ag * (n - 1) + g[i]) / n; al = (al * (n - 1) + l[i]) / n
        out[i] = 100 - 100 / (1 + ag / al) if al > 0 else 100
    return pd.Series(out, index=x.index)


def bollinger(x, n=20, k=2):
    m = x.rolling(n).mean(); s = x.rolling(n).std(ddof=0)  # desvío poblacional, como TA-Lib
    return m + k * s, m, m - k * s


ema = {n: ema_talib(close, n) for n in (20, 50, 200)}
rsi = rsi_wilder(close)
bb_up, bb_mid, bb_lo = bollinger(close)

# ---- referencia Alpha Vantage
bb_av = pd.read_csv(BB_FILE, parse_dates=["time"]).set_index("time").sort_index()
bb_av.columns = ["lo", "mid", "up"]   # orden de Alpha Vantage: Lower, Middle, Upper
# Puntos de control tomados de las respuestas RSI(14) y EMA(50) semanales de Alpha Vantage
rsi_av = pd.Series({"2026-10-30": 54.4108, "2026-05-29": 73.6298, "2025-04-04": 28.0005, "2024-03-28": 80.0712,
                    "2022-06-17": 30.8591, "2020-03-20": 21.6792, "2018-01-26": 92.2673, "2015-08-21": 38.0040,
                    "2011-08-19": 30.2768, "2008-10-10": 16.6548, "2003-03-07": 38.6374, "2000-02-18": 42.7646})
ema50_av = pd.Series({"2026-10-30": 719.3257, "2025-04-17": 545.2284, "2022-10-14": 383.5234, "2020-03-20": 270.8518,
                      "2016-02-12": 167.1601, "2012-06-01": 100.7386, "2008-10-10": 93.6857, "2003-03-14": 60.3833,
                      "2000-10-20": 90.3299})
rsi_av.index = pd.to_datetime(rsi_av.index); ema50_av.index = pd.to_datetime(ema50_av.index)

err_rsi = (rsi.reindex(rsi_av.index) - rsi_av).abs()
err_ema = (ema[50].reindex(ema50_av.index) - ema50_av).abs()
comun = bb_av.index.intersection(bb_up.dropna().index)
err_bb = pd.DataFrame({"up": (bb_up[comun] - bb_av.loc[comun, "up"]).abs(),
                       "mid": (bb_mid[comun] - bb_av.loc[comun, "mid"]).abs(),
                       "lo": (bb_lo[comun] - bb_av.loc[comun, "lo"]).abs()})
err_bb_rel = err_bb.div(bb_av.loc[comun, "mid"], axis=0) * 100  # en % del precio

# ---- "calibración" de los indicadores: ¿qué tan seguido el precio queda dentro de las bandas?
v = pd.DataFrame({"c": close, "u": bb_up, "l": bb_lo}).dropna()
dentro = float(((v.c <= v.u) & (v.c >= v.l)).mean()); arriba = float((v.c > v.u).mean()); abajo = float((v.c < v.l).mean())
# RSI: retorno de las 13 semanas siguientes según la zona (descriptivo, no es una regla de trading)
fwd13 = close.shift(-13) / close - 1
zonas = pd.cut(rsi, [0, 30, 50, 70, 100], labels=["<30", "30–50", "50–70", ">70"])
tabla_rsi = pd.DataFrame({"zona": zonas, "fwd": fwd13}).dropna().groupby("zona", observed=True)["fwd"].agg(["count", "median", lambda s: (s > 0).mean()])
tabla_rsi.columns = ["semanas", "mediana_13s", "prob_suba_13s"]

# ================================================================ GJR-GARCH + Monte Carlo
r = mg.log_retornos_pct(close)
rep = mg.analizar(r, [4, 13, 52], 20000, "simulation", 42, periodos_anio=PPA, h_banda=4)
_, res_full = mg.ajustar(r)
vol_cond = res_full.conditional_volatility * np.sqrt(PPA)  # % anual

# Calibración fuera de muestra: parámetros fijos estimados con el 70% inicial
split = r.index[int(len(r) * 0.7)]
_, res_tr = mg.ajustar(r, last_obs=split)
fc = res_tr.forecast(start=split, horizon=1, reindex=False)
s2 = fc.variance.iloc[:, 0]
real1 = r.shift(-1).loc[s2.index]; ok = real1.notna(); s2v, real1 = s2[ok], real1[ok]
mu, qf = res_tr.params["mu"], mg.ppf_innov(res_tr)
var95 = -(mu + np.sqrt(s2v) * float(qf(0.05))); var99 = -(mu + np.sqrt(s2v) * float(qf(0.01)))

rng = np.random.default_rng(0)
pos = {d: i for i, d in enumerate(r.index)}
niveles = [0.5, 0.8, 0.9, 0.98]
calib = {}
for H in (4, 13, 26, 52):
    pits, hits = [], {q: [] for q in niveles}
    origenes = [t for t in s2.index if pos[t] + H < len(r)]
    for t in origenes:
        sim = mg.simular_gjr(res_tr.params, s2.loc[t], H, 3000, rng, qf)
        real = r.iloc[pos[t] + 1:pos[t] + 1 + H].sum() / 100
        pits.append((sim < real).mean())
        for q in niveles:
            lo, hi = np.quantile(sim, [(1 - q) / 2, 1 - (1 - q) / 2])
            hits[q].append(lo <= real <= hi)
    pits = np.array(pits)
    # ventanas sin superposición para el test (las superpuestas están correlacionadas)
    no_sup = pits[::H]
    calib[H] = {"origenes": len(pits), "cobertura": {q: float(np.mean(hits[q])) for q in niveles},
                "pits": pits, "ks_p_sin_superposicion": float(stats.kstest(no_sup, "uniform").pvalue),
                "n_sin_superposicion": len(no_sup)}

# Monte Carlo hacia adelante: 52 semanas desde el último cierre
np.random.seed(42)
fc_mc = res_full.forecast(horizon=52, method="simulation", simulations=20000, reindex=False)
caminos = close.iloc[-1] * np.exp(np.cumsum(fc_mc.simulations.values[-1], axis=1) / 100)
fechas_fut = pd.date_range(close.index[-1], periods=53, freq="W-FRI")[1:]

# ================================================================ FIGURA 1: indicadores
ven = close.index >= close.index[-1] - pd.DateOffset(years=5)
fig = plt.figure(figsize=(12, 9.2))
gs = fig.add_gridspec(3, 2, height_ratios=[2.4, 1.1, 1.3], hspace=0.45, wspace=0.18)
ax = fig.add_subplot(gs[0, :])
ax.fill_between(close.index[ven], bb_lo[ven], bb_up[ven], color=C["band"], alpha=0.55, lw=0, label="Bandas de Bollinger (20, ±2σ)")
ax.plot(close.index[ven], close[ven], color=C["ink"], lw=1.4, label="SPY (ajustado)")
for n, col in ((20, "blue"), (50, "orange"), (200, "aqua")):
    ax.plot(ema[n].index[ven], ema[n][ven], color=C[col], lw=1.6, label=f"EMA {n}")
    ax.annotate(f"EMA {n}", (ema[n].index[-1], ema[n].iloc[-1]), xytext=(6, 0), textcoords="offset points",
                fontsize=8.5, color=C["ink2"], va="center")
pts = ema50_av[ema50_av.index >= close.index[ven][0]]
ax.scatter(pts.index, pts.values, s=60, facecolor="none", edgecolor=C["ink"], lw=1.4, zorder=5,
           label="EMA 50 según Alpha Vantage (control)")
ax.set_title("1A · SPY semanal: tendencia (EMA 20/50/200) y volatilidad (Bollinger), últimos 5 años")
ax.legend(loc="upper left", ncol=3, fontsize=8.5)
ax.set_xlim(close.index[ven][0], close.index[-1] + pd.Timedelta(weeks=14))
ax.yaxis.set_major_formatter(USD)

ax = fig.add_subplot(gs[1, :], sharex=fig.axes[0])
ax.axhspan(70, 100, color=C["orange"], alpha=0.08, lw=0); ax.axhspan(0, 30, color=C["blue"], alpha=0.08, lw=0)
ax.plot(rsi.index[ven], rsi[ven], color=C["blue"], lw=1.5, label="RSI 14 (propio)")
pts = rsi_av[rsi_av.index >= close.index[ven][0]]
ax.scatter(pts.index, pts.values, s=60, facecolor="none", edgecolor=C["ink"], lw=1.4, zorder=5, label="RSI según Alpha Vantage")
ax.axhline(70, color=C["ink2"], lw=0.8, ls="--"); ax.axhline(30, color=C["ink2"], lw=0.8, ls="--")
ax.text(1.002, 70, "70 sobrecompra", transform=ax.get_yaxis_transform(), fontsize=8, color=C["ink2"], va="center")
ax.text(1.002, 30, "30 sobreventa", transform=ax.get_yaxis_transform(), fontsize=8, color=C["ink2"], va="center")
ax.set_ylim(10, 95); ax.set_title("1B · Impulso: RSI 14"); ax.legend(loc="lower left", fontsize=8.5, ncol=2)

ax = fig.add_subplot(gs[2, 0])
ax.plot(err_bb_rel.index, err_bb_rel["up"], color=C["blue"], lw=1, label="Banda superior")
ax.plot(err_bb_rel.index, err_bb_rel["lo"], color=C["orange"], lw=1, label="Banda inferior")
ax.set_title("1C · Error vs Alpha Vantage: Bollinger (toda la serie)")
ax.set_ylabel("|diferencia| en millonésimas del precio"); ax.legend(fontsize=8.5, loc="center right")
err_rsi_est = err_rsi.drop(err_rsi.index.min())  # el primer valor depende de la semilla de cada librería
ax.text(0.02, 0.97, f"Bollinger: error máx. {es(err_bb_rel.max().max() * 1e4, 1)} millonésimas ({len(comun)} semanas)\n"
                    f"RSI 14: error máx. {es(err_rsi_est.max(), 4)} pts ({len(err_rsi_est)} fechas de control)\n"
                    f"   la 1ª semana de arranque difiere {es(err_rsi[err_rsi.index.min()], 2)} pts\n"
                    f"EMA 50: error máx. US$ {es(err_ema.max(), 5)} ({len(err_ema)} fechas)",
        transform=ax.transAxes, fontsize=8, color=C["ink"], va="top",
        bbox=dict(boxstyle="round,pad=0.4", fc=C["surf"], ec=C["grid"]))
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda y, _: es(y * 1e4, 1)))
ax.set_ylim(0, err_bb_rel.max().max() * 2.1)
ax.xaxis.set_major_locator(mdates.YearLocator(5)); ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))

ax = fig.add_subplot(gs[2, 1])
cats = ["Dentro", "Arriba", "Abajo"]; vals = [dentro * 100, arriba * 100, abajo * 100]
bars = ax.bar(cats, vals, color=[C["blue"], C["orange"], C["aqua"]], width=0.55)
ax.axhline(95.4, color=C["ink2"], ls="--", lw=0.9)
ax.text(2.35, 97, "95,4% si los retornos\nfueran normales", fontsize=7.5, color=C["ink2"], va="bottom", ha="left")
for b, vv in zip(bars, vals):
    y_ = vv / 2 if vv > 50 else vv + 1.5
    ax.text(b.get_x() + b.get_width() / 2, y_, es(vv, 1) + "%", ha="center", fontsize=9.5,
            color=C["surf"] if vv > 50 else C["ink"], fontweight="bold" if vv > 50 else "normal")
ax.set_ylim(0, 112); ax.set_xlim(-0.6, 3.6)
ax.set_title("1D · ¿Dónde cerró el precio respecto de las bandas?")
ax.set_ylabel("% de semanas")
fig.suptitle("Indicadores técnicos: cálculo propio verificado contra Alpha Vantage", x=0.01, ha="left",
             fontsize=14, fontweight="bold", color=C["ink"])
pie(fig)
fig.savefig(f"{OUT}/1_indicadores.png", dpi=160, bbox_inches="tight"); plt.close(fig)

# ================================================================ FIGURA 2: modelo + Monte Carlo
fig = plt.figure(figsize=(12, 9))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.35], hspace=0.38, wspace=0.2)
ax = fig.add_subplot(gs[0, 0])
real_abs = (r.abs() * np.sqrt(PPA)).rolling(4).mean()
ax.plot(real_abs.index, real_abs, color=C["grid"], lw=0.9, label="|retorno| semanal anualizado (prom. 4 sem.)")
ax.plot(vol_cond.index, vol_cond, color=C["blue"], lw=1.4, label="Volatilidad GJR-GARCH (anual)")
lp = rep["volatilidad_anual_tipica"] * 100
ax.axhline(lp, color=C["ink2"], ls="--", lw=0.9, label=f"Nivel típico (mediana): {es(lp, 1)}%")
ax.set_title("2A · La volatilidad viene en racimos"); ax.set_ylabel("% anual")
ax.legend(fontsize=8, loc="upper right"); ax.set_ylim(0, max(110, float(vol_cond.max()) * 1.05))
ax.xaxis.set_major_locator(mdates.YearLocator(5)); ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))

ax = fig.add_subplot(gs[0, 1])
p = res_full.params
_, res_sym = mg.ajustar(r, o=0); ps = res_sym.params
eps = np.linspace(-8, 8, 200)
s2_lp = r.var()   # varianza histórica como punto de partida común
nic = p["omega"] + p["beta[1]"] * s2_lp + (p["alpha[1]"] + p["gamma[1]"] * (eps < 0)) * eps ** 2
nic_s = ps["omega"] + ps["beta[1]"] * s2_lp + ps["alpha[1]"] * eps ** 2
ax.plot(eps, np.sqrt(nic * PPA), color=C["blue"], label="GJR (asimétrico)")
ax.plot(eps, np.sqrt(nic_s * PPA), color=C["orange"], label="GARCH simétrico")
ax.set_xlabel("Shock de la semana anterior (%)"); ax.set_ylabel("Volatilidad siguiente (% anual)")
ax.set_title(f"2B · Una caída agita más que una suba (γ = {es(p['gamma[1]'], 2)}; α = {es(p['alpha[1]'], 2)})")
ax.legend(fontsize=8.5, loc="upper center")

ax = fig.add_subplot(gs[1, :])
hist = close[close.index >= close.index[-1] - pd.DateOffset(years=2)]
ax.plot(hist.index, hist, color=C["ink"], lw=1.4, label="SPY (histórico)")
q = np.quantile(caminos, [0.05, 0.25, 0.5, 0.75, 0.95], axis=0)
ax.fill_between(fechas_fut, q[0], q[4], color=C["blue"], alpha=0.15, lw=0, label="90% de los escenarios (p5–p95)")
ax.fill_between(fechas_fut, q[1], q[3], color=C["blue"], alpha=0.30, lw=0, label="50% de los escenarios (p25–p75)")
for i in range(25):
    ax.plot(fechas_fut, caminos[i], color=C["blue"], lw=0.4, alpha=0.35, label="25 caminos de ejemplo" if i == 0 else None)
ax.plot(fechas_fut, q[2], color=C["blue"], lw=2, label="Mediana")
p0 = close.iloc[-1]
for qq, lab in ((q[0][-1], "p5"), (q[2][-1], "mediana"), (q[4][-1], "p95")):
    ax.annotate(f"{lab}: ${es(qq, 0)} ({pct(qq / p0 - 1, 1, True)})", (fechas_fut[-1], qq), xytext=(6, 0),
                textcoords="offset points", fontsize=8.5, color=C["ink"], va="center")
h52 = rep["montecarlo"]["horizontes"]["52_periodos"]
ax.set_title(f"2C · Monte Carlo a 52 semanas, 20.000 caminos.  P(perder) = {pct(h52['prob_perder'], 0)} · "
             f"P(perder más de 10%) = {pct(h52['prob_perder_mas_10pct'])} · ES 95% = −{pct(h52['es_95'])}")
ax.set_ylim(min(hist.min(), q[0].min()) * 0.85, q[4].max() * 1.12)
ax.legend(fontsize=8.5, loc="upper left")
ax.set_xlim(hist.index[0], fechas_fut[-1] + pd.Timedelta(weeks=22))
ax.yaxis.set_major_formatter(USD)
fig.suptitle("GJR-GARCH(1,1,1) con t asimétrica (skew-t) y simulación Monte Carlo", x=0.01, ha="left",
             fontsize=14, fontweight="bold", color=C["ink"])
pie(fig)
fig.savefig(f"{OUT}/2_modelo_montecarlo.png", dpi=160, bbox_inches="tight"); plt.close(fig)

# ================================================================ FIGURA 3: calibración
fig = plt.figure(figsize=(12, 8.6))
gs = fig.add_gridspec(2, 2, height_ratios=[1.15, 1], hspace=0.4, wspace=0.22)
ax = fig.add_subplot(gs[0, :])
ax.bar(real1.index, real1, width=5, color=C["grid"], label="Retorno semanal real")
ax.plot(var95.index, -var95, color=C["orange"], lw=1.2, label="−VaR 95%")
ax.plot(var99.index, -var99, color=C["red"], lw=1.2, label="−VaR 99%")
e95 = real1 < -var95; e99 = real1 < -var99
ax.scatter(real1.index[e95 & ~e99], real1[e95 & ~e99], s=24, color=C["orange"], zorder=5, label=f"Excepción 95% ({int(e95.sum())})")
ax.scatter(real1.index[e99], real1[e99], s=40, color=C["red"], marker="D", zorder=6, label=f"Excepción 99% ({int(e99.sum())})")
bt = rep["backtest_var_1d_fuera_de_muestra"]
ax.set_title(f"3A · VaR a 1 semana fuera de muestra ({real1.index[0]:%Y}–{real1.index[-1]:%Y}), con parámetros estimados solo con 1999–{real1.index[0]:%Y}\n"
             f"95%: {bt['var_95']['excepciones']} excepciones vs {es(bt['var_95']['esperadas'], 1)} esperadas "
             f"(Kupiec p = {es(bt['var_95']['p_kupiec'], 2)})   ·   99%: {bt['var_99']['excepciones']} vs "
             f"{es(bt['var_99']['esperadas'], 1)} (p = {es(bt['var_99']['p_kupiec'], 2)})")
ax.set_ylabel("% log semanal"); ax.legend(fontsize=8.5, ncol=5, loc="lower left")

ax = fig.add_subplot(gs[1, 0])
ax.plot([40, 100], [40, 100], color=C["ink2"], ls="--", lw=0.9)
ax.text(42, 44, "calibración perfecta", fontsize=8, color=C["ink2"], rotation=33)
for H, col in ((4, "blue"), (13, "orange"), (26, "aqua"), (52, "yellow")):
    cov = calib[H]["cobertura"]
    xs = [k * 100 for k in cov]; ys = [v * 100 for v in cov.values()]
    ax.plot(xs, ys, color=C[col], marker="o", ms=7,
            label=f"{H} semanas ({calib[H]['n_sin_superposicion']} ventanas independientes)")
ax.set_xlabel("Cobertura que promete la banda (%)"); ax.set_ylabel("Cobertura real fuera de muestra (%)")
ax.set_title("3B · ¿Las bandas cumplen lo que prometen?")
ax.text(42, 98, "arriba de la diagonal: bandas anchas (conservador)", fontsize=7.5, color=C["ink2"], va="top")
ax.text(99, 64, "abajo: bandas angostas\n(subestima el riesgo)", fontsize=7.5, color=C["ink2"], ha="right")
ax.legend(fontsize=8, loc="lower right"); ax.set_xlim(40, 102); ax.set_ylim(40, 102)

ax = fig.add_subplot(gs[1, 1])
pit = calib[4]["pits"]
ax.hist(pit, bins=10, range=(0, 1), color=C["blue"], edgecolor=C["surf"], lw=2)
ax.axhline(len(pit) / 10, color=C["ink2"], ls="--", lw=0.9)
ax.text(0.5, len(pit) / 10 * 1.04, "altura esperada si está calibrado", fontsize=8, color=C["ink2"], ha="center")
ax.set_xlabel("Percentil del resultado real dentro de la simulación (PIT)")
ax.set_ylabel("Cantidad de orígenes")
ax.set_title(f"3C · PIT a 4 semanas (KS p = {es(calib[4]['ks_p_sin_superposicion'], 2)}, n = {calib[4]['n_sin_superposicion']})")
fig.suptitle(f"Calibración fuera de muestra · veredicto del script: {rep['veredicto']}", x=0.01, ha="left",
             fontsize=14, fontweight="bold", color=C["ink"])
pie(fig)
fig.savefig(f"{OUT}/3_calibracion.png", dpi=160, bbox_inches="tight"); plt.close(fig)

# ================================================================ resumen
resumen = {
    "indicadores_vs_alpha_vantage": {
        "rsi_error_abs_max_puntos": round(float(err_rsi.max()), 5),
        "rsi_error_por_fecha": {str(k.date()): round(float(v), 5) for k, v in err_rsi.items()},
        "ema50_error_abs_max_usd": round(float(err_ema.max()), 5),
        "bollinger_error_max_pct_precio": round(float(err_bb_rel.max().max()), 6),
        "bollinger_semanas_comparadas": int(len(comun)),
    },
    "bollinger_cobertura": {"dentro": round(dentro, 4), "arriba": round(arriba, 4), "abajo": round(abajo, 4)},
    "rsi_zona_vs_retorno_13s": {str(k): {c: round(float(v), 4) for c, v in row.items()} for k, row in tabla_rsi.iterrows()},
    "estado_tecnico_hoy": {
        "precio": round(float(close.iloc[-1]), 2), "ema20": round(float(ema[20].iloc[-1]), 2),
        "ema50": round(float(ema[50].iloc[-1]), 2), "ema200": round(float(ema[200].iloc[-1]), 2),
        "rsi": round(float(rsi.iloc[-1]), 2),
        "pct_b": round(float((close.iloc[-1] - bb_lo.iloc[-1]) / (bb_up.iloc[-1] - bb_lo.iloc[-1])), 3),
        "ancho_banda": round(float((bb_up.iloc[-1] - bb_lo.iloc[-1]) / bb_mid.iloc[-1]), 4),
        "ancho_banda_percentil_6m": round(float(((bb_up - bb_lo) / bb_mid).iloc[-26:].rank(pct=True).iloc[-1]), 3),
    },
    "modelo": {k: rep[k] for k in ("parametros", "p_values", "persistencia", "vida_media_shock_periodos",
                                   "volatilidad_anual_hoy", "volatilidad_anual_tipica", "volatilidad_anual_muestral",
                                   "volatilidad_anual_largo_plazo_modelo", "regimen_volatilidad", "distribucion",
                                   "asimetria", "diagnostico_residuos", "checks", "veredicto", "avisos")},
    "backtest": rep["backtest_var_1d_fuera_de_muestra"],
    "calibracion_bandas": {H: {"origenes": v["origenes"], "cobertura": v["cobertura"],
                               "ks_p_sin_superposicion": round(v["ks_p_sin_superposicion"], 4),
                               "n_sin_superposicion": v["n_sin_superposicion"]} for H, v in calib.items()},
    "montecarlo": rep["montecarlo"]["horizontes"],
}
json.dump(resumen, open(f"{OUT}/resumen.json", "w"), indent=2, ensure_ascii=False, default=str)
print(json.dumps(resumen, indent=1, ensure_ascii=False, default=str))
