#!/usr/bin/env python3
"""
Seguimiento de cartera del Analista Researcher.

Uso:
  python seguimiento_cartera.py --cartera cartera.json --precios precios.csv [--caja caja.json]
                                [--fecha AAAA-MM-DD] [--grafico seguimiento.png] [--salida reporte.json]
  python seguimiento_cartera.py --selftest

Entradas
- cartera.json: moneda base, perfil, límites, posiciones (con peso objetivo y fecha en que se necesita
  la plata) y movimientos (compras, ventas, cupones/amortizaciones/dividendos). Ver ejemplo en ejemplo_cartera/.
- precios.csv (formato largo): fecha, activo, precio. Incluye:
    * precio de cada activo en SU moneda (bonos: por cada 100 de valor nominal),
    * tipo de cambio "FX_<MONEDA>" = unidades de moneda base por 1 unidad de esa moneda (p. ej. FX_USD),
    * benchmarks como índices de nivel (p. ej. BM_CAUCION, BM_IPC, FX_USD).
- caja.json (opcional): bloque de salida del Analista de Caja, con "huecos_proyectados".

Salida: JSON con valuación, rendimiento (TWR y TIR), comparación con benchmarks y en términos reales,
desvíos contra el objetivo, riesgo, calce con la caja y alertas priorizadas. Opcional: gráfico PNG.
No da órdenes de compra o venta: calcula el ajuste necesario para volver al objetivo y la skill decide
cómo mostrarlo según el modo (educativo o agente).
"""
import argparse
import json
import sys
from datetime import date

import numpy as np
import pandas as pd
from scipy.optimize import brentq

LIMITES_DEFECTO = {
    "banda_absoluta_pp": 5.0,        # desvío de peso tolerado, en puntos porcentuales
    "banda_relativa": 0.25,          # o 25% del peso objetivo, lo que sea mayor
    "concentracion_emisor_max": 0.30,
    "drawdown_alerta": 0.10,         # caída desde el máximo de la cartera
    "perdida_posicion_alerta": 0.15, # caída de una posición contra su costo
    "dias_aviso_uso": 30,            # avisar cuando falta menos que esto para usar la plata
    "dias_aviso_vencimiento": 30,
    "dias_sin_precio": 5,
}
SEVERIDAD = {"alta": 0, "media": 1, "info": 2}


# ================================================================ utilidades
def es(x, d=1):
    """Número con coma decimal y punto de miles."""
    return f"{x:,.{d}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def nn(x):
    """None si el valor falta (None o NaN)."""
    return None if x is None or (isinstance(x, float) and np.isnan(x)) else x


def xirr(flujos):
    """TIR anual de flujos [(fecha, monto)] desde el punto de vista del inversor (aportes < 0)."""
    if not flujos:
        return None
    t0 = min(f for f, _ in flujos)
    ts = np.array([(f - t0).days / 365.0 for f, _ in flujos]); cs = np.array([c for _, c in flujos])
    if not (cs.min() < 0 < cs.max()):
        return None
    npv = lambda r: np.sum(cs / (1 + r) ** ts)  # noqa: E731
    try:
        return float(brentq(npv, -0.9999, 100.0))
    except ValueError:
        return None


def max_drawdown(indice):
    pico = indice.cummax()
    dd = indice / pico - 1
    return float(dd.min()), float(dd.iloc[-1]), dd


def frecuencia_anual(idx):
    paso = np.median(np.diff(idx.values).astype("timedelta64[D]").astype(int)) if len(idx) > 1 else 1
    return 252 if paso <= 1 else 52 if paso <= 7 else 12


# ================================================================ núcleo
class Cartera:
    def __init__(self, cfg, precios, fecha=None, caja=None):
        self.cfg = cfg
        self.base = cfg.get("moneda_base", "ARS")
        self.lim = {**LIMITES_DEFECTO, **cfg.get("limites", {})}
        self.pos = {p["id"]: p for p in cfg["posiciones"]}
        self.caja = caja or {}
        px = precios.copy()
        px["fecha"] = pd.to_datetime(px["fecha"])
        self.ultimo_dato = px.groupby("activo")["fecha"].max()
        self.px = px.pivot_table(index="fecha", columns="activo", values="precio").sort_index().ffill()
        self.fecha = pd.Timestamp(fecha) if fecha else self.px.index.max()
        self.px = self.px.loc[: self.fecha]
        mov = pd.DataFrame(cfg.get("movimientos", []))
        mov["fecha"] = pd.to_datetime(mov["fecha"])
        self.mov = mov[mov["fecha"] <= self.fecha].sort_values("fecha")
        inicio = self.mov["fecha"].min()
        self.px = self.px.loc[inicio:]
        self._validar()

    # -------- datos
    def _validar(self):
        faltan = [a for a in self.pos if a not in self.px.columns]
        monedas = {p.get("moneda", self.base) for p in self.pos.values()} - {self.base}
        faltan += [f"FX_{m}" for m in monedas if f"FX_{m}" not in self.px.columns]
        if faltan:
            sys.exit(f"Faltan precios para: {', '.join(faltan)}")

    def fx(self, moneda):
        if moneda == self.base:
            return pd.Series(1.0, index=self.px.index)
        return self.px[f"FX_{moneda}"]

    def precio_base(self, activo):
        p = self.pos[activo]
        factor = p.get("factor_precio", 0.01 if p.get("tipo") == "bono" else 1.0)  # bonos cotizan cada 100 VN
        return self.px[activo] * factor * self.fx(p.get("moneda", self.base))

    # -------- tenencias y flujos
    def tenencias(self):
        """Cantidades por día, flujos externos por día (en moneda base) y costo/realizado por posición."""
        idx = self.px.index
        cant = pd.DataFrame(0.0, index=idx, columns=list(self.pos))
        flujo = pd.Series(0.0, index=idx)            # aportes (+) y retiros (−) netos del día
        flujos_tir = []
        costo = {a: 0.0 for a in self.pos}; realizado = {a: 0.0 for a in self.pos}; cobrado = {a: 0.0 for a in self.pos}
        for _, m in self.mov.iterrows():
            a, d = m["activo"], m["fecha"]
            dia = idx[idx.get_indexer([d], method="bfill")[0]]
            p = self.pos[a]
            fx = float(self.fx(p.get("moneda", self.base)).loc[dia])
            factor = p.get("factor_precio", 0.01 if p.get("tipo") == "bono" else 1.0)
            if m["tipo"] in ("compra", "venta"):
                q = float(m["cantidad"]); precio = float(m["precio"])
                monto = q * precio * factor * fx + float(m.get("comision", 0) or 0) * (1 if m["tipo"] == "compra" else -1)
                if m["tipo"] == "compra":
                    cant.loc[dia:, a] += q; costo[a] += monto; flujo[dia] += monto; flujos_tir.append((d.date(), -monto))
                else:
                    q_prev = float(cant.loc[dia, a])
                    costo_vendido = costo[a] * q / q_prev if q_prev else 0
                    realizado[a] += monto - costo_vendido; costo[a] -= costo_vendido
                    cant.loc[dia:, a] -= q; flujo[dia] -= monto; flujos_tir.append((d.date(), monto))
            elif m["tipo"] in ("cupon", "amortizacion", "dividendo", "renta"):
                monto = float(m["monto"]) * fx      # monto en la moneda del activo
                if m["tipo"] == "amortizacion":
                    cant.loc[dia:, a] *= 1 - float(m.get("fraccion_vn", 0))
                    costo[a] *= 1 - float(m.get("fraccion_vn", 0))
                cobrado[a] += monto; flujo[dia] -= monto; flujos_tir.append((d.date(), monto))
        return cant, flujo, flujos_tir, costo, realizado, cobrado

    # -------- cálculo principal
    def reporte(self):
        cant, flujo, flujos_tir, costo, realizado, cobrado = self.tenencias()
        valores = pd.DataFrame({a: cant[a] * self.precio_base(a) for a in self.pos})
        V = valores.sum(axis=1)
        vivos = V > 0
        V, valores, flujo = V[vivos], valores[vivos], flujo[vivos]

        # TWR: encadena retornos diarios neutralizando aportes y retiros
        r = ((V - flujo) / V.shift(1) - 1).iloc[1:]
        indice = (1 + r).cumprod(); indice = pd.concat([pd.Series([1.0], index=[V.index[0]]), indice])
        twr = float(indice.iloc[-1] - 1)
        dias = (V.index[-1] - V.index[0]).days
        twr_anual = (1 + twr) ** (365 / dias) - 1 if dias >= 30 else None
        tir = xirr(flujos_tir + [(self.fecha.date(), float(V.iloc[-1]))])
        ppa = frecuencia_anual(V.index)
        vol = float(r.std() * np.sqrt(ppa)) if len(r) > 10 else None
        mdd, dd_hoy, dd = max_drawdown(indice)
        var_1m = float(1.645 * vol / np.sqrt(12)) if vol else None  # aproximación normal a 1 mes

        # Benchmarks (índices de nivel) en el mismo período
        bms = {}
        for nombre, serie in self.cfg.get("benchmarks", {}).items():
            if serie in self.px.columns:
                s = self.px[serie].loc[V.index[0]:]
                bms[nombre] = {"serie": serie, "retorno": float(s.iloc[-1] / s.iloc[0] - 1),
                               "indice": (s / s.iloc[0])}
        inflacion = bms.get("inflacion", {}).get("retorno")
        real = (1 + twr) / (1 + inflacion) - 1 if inflacion is not None else None

        # Posiciones
        total = float(V.iloc[-1]); hoy = self.fecha
        filas = []
        for a, p in self.pos.items():
            val = float(valores[a].iloc[-1]); peso = val / total if total else 0
            obj = float(p.get("peso_objetivo", 0))
            banda = max(self.lim["banda_absoluta_pp"] / 100, self.lim["banda_relativa"] * obj)
            res_no_real = val - costo[a] if cant[a].iloc[-1] > 0 else 0.0
            base_costo = costo[a] if costo[a] > 0 else None
            uso = pd.Timestamp(p["se_necesita_el"]) if p.get("se_necesita_el") else None
            venc = pd.Timestamp(p["vencimiento"]) if p.get("vencimiento") else None
            filas.append({
                "id": a, "categoria": p.get("categoria"), "moneda": p.get("moneda", self.base), "emisor": p.get("emisor"),
                "cantidad": round(float(cant[a].iloc[-1]), 4), "precio": round(float(self.px[a].iloc[-1]), 4),
                "valor_base": round(val, 2), "peso": round(peso, 4), "peso_objetivo": obj,
                "desvio_pp": round((peso - obj) * 100, 2), "banda_pp": round(banda * 100, 2),
                "fuera_de_banda": bool(abs(peso - obj) > banda),
                "ajuste_para_objetivo_base": round(obj * total - val, 2),
                "resultado_no_realizado": round(res_no_real, 2),
                "resultado_no_realizado_pct": round(res_no_real / base_costo, 4) if base_costo else None,
                "resultado_realizado": round(realizado[a], 2), "rentas_cobradas": round(cobrado[a], 2),
                "dias_hasta_uso": (uso - hoy).days if uso is not None else None,
                "dias_hasta_vencimiento": (venc - hoy).days if venc is not None else None,
                "liquidez_dias": p.get("liquidez_dias"), "duration_modificada": p.get("duration_modificada"),
                "uso_futuro": p.get("uso_futuro"),
            })
        pos = pd.DataFrame(filas).set_index("id")

        # Concentración por emisor y duration de la renta fija
        conc = pos.groupby("emisor")["peso"].sum().sort_values(ascending=False)
        rf = pos[pos["duration_modificada"].notna() & (pos["peso"] > 0)]
        dur = float((rf["duration_modificada"] * rf["peso"]).sum() / rf["peso"].sum()) if len(rf) else None

        alertas = self._alertas(pos, conc, mdd, dd_hoy, total)
        calce = self._calce_caja(pos, total)
        alertas += calce.pop("alertas")
        alertas.sort(key=lambda x: SEVERIDAD[x["severidad"]])

        self._series = {"indice": indice, "dd": dd, "bms": bms, "valores": valores}
        return {
            "fecha": str(self.fecha.date()), "moneda_base": self.base, "perfil": self.cfg.get("perfil"),
            "valor_total": round(total, 2),
            "rendimiento": {
                "desde": str(V.index[0].date()), "dias": dias,
                "twr": round(twr, 4), "twr_anualizado": round(twr_anual, 4) if twr_anual is not None else None,
                "tir_anual_mwr": round(tir, 4) if tir is not None else None,
                "real_vs_inflacion": round(real, 4) if real is not None else None,
                "benchmarks": {k: round(v["retorno"], 4) for k, v in bms.items()},
                "exceso_vs_benchmarks_pp": {k: round((twr - v["retorno"]) * 100, 2) for k, v in bms.items()},
            },
            "riesgo": {
                "volatilidad_anual": round(vol, 4) if vol else None,
                "var95_1mes_aprox": round(var_1m, 4) if var_1m else None,
                "max_drawdown": round(mdd, 4), "drawdown_actual": round(dd_hoy, 4),
                "duration_modificada_renta_fija": round(dur, 2) if dur else None,
                "concentracion_emisor": {k: round(float(v), 4) for k, v in conc.items()},
            },
            "posiciones": [{k: nn(v) for k, v in fila.items()} for fila in pos.reset_index().to_dict(orient="records")],
            "calce_caja": calce,
            "alertas": alertas,
        }

    # -------- alertas
    def _alertas(self, pos, conc, mdd, dd_hoy, total):
        L, al = self.lim, []

        def add(sev, tipo, activo, texto, **datos):
            al.append({"severidad": sev, "tipo": tipo, "activo": activo, "texto": texto, **datos})

        for a, f in pos.iterrows():
            if f["cantidad"] <= 0:
                continue
            du, dv, liq = nn(f["dias_hasta_uso"]), nn(f["dias_hasta_vencimiento"]), nn(f["liquidez_dias"])
            if du is not None and dv is not None and dv > du:
                add("alta", "calce", a, f"Vence {int(dv - du)} días DESPUÉS de la fecha en que necesitás esta plata: "
                    "habría que venderlo antes, al precio de mercado de ese día.", dias_desfase=int(dv - du))
            if du is not None and liq is not None and liq > du:
                add("alta", "liquidez", a, f"Tarda {int(liq)} días en hacerse efectivo y la plata se necesita en {int(du)}.")
            if du is not None and 0 <= du <= L["dias_aviso_uso"] and f["categoria"] not in ("FCI money market", "Caución", "Cuenta remunerada"):
                add("media", "uso_cercano", a, f"Faltan {int(du)} días para usar esta plata: conviene pasarla a algo líquido "
                    "y sin riesgo de precio.")
            if dv is not None and 0 <= dv <= L["dias_aviso_vencimiento"]:
                add("info", "vencimiento", a, f"Vence en {int(dv)} días: definir si se reinvierte o se pasa a la caja.")
            if f["fuera_de_banda"]:
                lado = "por encima" if f["desvio_pp"] > 0 else "por debajo"
                add("media", "desvio", a, f"Pesa {es(f['peso'] * 100)}% contra {es(f['peso_objetivo'] * 100, 0)}% objetivo "
                    f"({es(abs(f['desvio_pp']))} pp {lado}; tolerancia ±{es(f['banda_pp'])} pp).",
                    ajuste_base=f["ajuste_para_objetivo_base"])
            pnl = nn(f["resultado_no_realizado_pct"])
            if pnl is not None and pnl <= -L["perdida_posicion_alerta"]:
                add("media", "perdida", a, f"Cae {es(abs(pnl) * 100)}% contra su costo: revisar si la razón por la que "
                    "entró sigue en pie (no es una orden de venta).")
            ultimo = self.ultimo_dato.get(a)
            if ultimo is not None and (self.fecha - ultimo).days > L["dias_sin_precio"]:
                add("media", "dato_viejo", a, f"El último precio es del {ultimo:%d/%m/%Y}: la valuación puede estar desactualizada.")
        for emisor, w in conc.items():
            if w > L["concentracion_emisor_max"]:
                add("media", "concentracion", emisor, f"{es(w * 100, 0)}% de la cartera depende de un mismo emisor "
                    f"(límite {es(L['concentracion_emisor_max'] * 100, 0)}%).")
        if dd_hoy <= -L["drawdown_alerta"]:
            add("alta", "drawdown", None, f"La cartera está {es(abs(dd_hoy) * 100)}% abajo de su máximo.")
        return al

    # -------- calce con la caja
    def _calce_caja(self, pos, total):
        """Cubre los huecos de la caja en orden de fecha, descontando lo que ya usó cada hueco anterior.
        Prioridad para liquidar: 1) lo que vence antes del hueco (no hay que vender a precio de mercado),
        2) lo que se hace efectivo más rápido, 3) lo que tiene menor riesgo de precio."""
        huecos = sorted(self.caja.get("huecos_proyectados", []), key=lambda h: h["fecha"])
        vivas = pos[pos["cantidad"] > 0].copy()
        riesgo = {"FCI money market": 0, "Caución": 0, "Cuenta remunerada": 0, "Plazo fijo": 1, "Letra tasa fija": 2,
                  "Bono CER": 3, "ON en dólares": 4, "Bono soberano en dólares": 5, "CEDEAR": 6, "Acción": 6}
        vivas["_r"] = vivas["categoria"].map(riesgo).fillna(5)
        vivas["_liq"] = vivas["liquidez_dias"].astype(float).fillna(3)
        saldo = vivas["valor_base"].astype(float).to_dict()          # lo que queda de cada posición
        resultado, alertas = [], []
        for h in huecos:
            fecha_h = pd.Timestamp(h["fecha"]); monto = float(h["monto"]); dias = (fecha_h - self.fecha).days
            venc = vivas["dias_hasta_vencimiento"].astype(float)
            vivas["_vence_antes"] = (venc.notna() & (venc <= dias)).map({True: 0, False: 1})
            candidatas = vivas[vivas["_liq"] <= max(dias, 0)].sort_values(["_vence_antes", "_liq", "_r"])
            cubre = float(sum(saldo[a] for a in candidatas.index))
            plan, falta = [], monto
            for a, f in candidatas.iterrows():
                if falta <= 0:
                    break
                usar = min(falta, saldo[a])
                if usar <= 0:
                    continue
                antes_de_vencer = nn(f["dias_hasta_vencimiento"]) is not None and f["dias_hasta_vencimiento"] > dias
                plan.append({"activo": a, "categoria": f["categoria"], "monto_base": round(usar, 2),
                             "se_vende_antes_del_vencimiento": bool(antes_de_vencer),
                             "estaba_reservado_para": f.get("uso_futuro")})
                saldo[a] -= usar; falta -= usar
            resultado.append({"fecha": str(fecha_h.date()), "monto": monto, "motivo": h.get("motivo"), "dias": dias,
                              "liquido_a_tiempo_restante": round(cubre, 2), "cubierto": bool(cubre >= monto),
                              "orden_sugerido_de_liquidacion": plan})
            if cubre < monto:
                alertas.append({"severidad": "alta", "tipo": "hueco_caja", "activo": None,
                                "texto": f"La caja proyecta un hueco de ${es(monto, 0)} para el {fecha_h:%d/%m} y solo "
                                         f"${es(cubre, 0)} de la cartera se puede hacer efectivo a tiempo."})
            else:
                forzadas = [x for x in plan if x["se_vende_antes_del_vencimiento"] and x["categoria"] not in
                            ("FCI money market", "Caución", "Cuenta remunerada")]
                if forzadas:
                    nombres = ", ".join(x["activo"] for x in forzadas)
                    alertas.append({"severidad": "media", "tipo": "hueco_caja", "activo": nombres,
                                    "texto": f"Para cubrir el hueco del {fecha_h:%d/%m} (${es(monto, 0)}) habría que vender "
                                             f"{nombres} antes de su vencimiento, al precio de mercado de ese día."})
                elif dias <= self.lim["dias_aviso_uso"]:
                    alertas.append({"severidad": "media", "tipo": "hueco_caja", "activo": None,
                                    "texto": f"En {dias} días la caja necesita ${es(monto, 0)}: la cartera lo cubre; "
                                             "conviene dejar lista la liquidación."})
        return {"huecos": resultado, "alertas": alertas}

    # -------- gráfico
    def grafico(self, rep, ruta):
        import matplotlib
        matplotlib.use("Agg")
        import logging
        logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
        import matplotlib.pyplot as plt
        import matplotlib.dates as mdates
        C = {"blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a", "yellow": "#eda100", "red": "#d03b3b",
             "ink": "#0b0b0b", "ink2": "#52514e", "grid": "#e4e3df", "surf": "#fcfcfb", "band": "#cde2fb"}
        plt.rcParams.update({"font.family": ["Aptos", "DejaVu Sans"], "font.size": 9.5, "axes.grid": True,
                             "grid.color": C["grid"], "axes.edgecolor": C["grid"], "axes.spines.top": False,
                             "axes.spines.right": False, "figure.facecolor": C["surf"], "axes.facecolor": C["surf"],
                             "axes.titleweight": "bold", "axes.titlelocation": "left", "axes.titlesize": 11,
                             "xtick.color": C["ink2"], "ytick.color": C["ink2"], "legend.frameon": False})
        s = self._series
        fig = plt.figure(figsize=(12, 8.8))
        gs = fig.add_gridspec(2, 2, hspace=0.42, wspace=0.28)

        ax = fig.add_subplot(gs[0, 0])
        nombres = {"caucion": "Caución", "inflacion": "Inflación (IPC)", "dolar": "Dólar", "plazo_fijo": "Plazo fijo"}
        fin = lambda serie: es((serie.iloc[-1] - 1) * 100)  # noqa: E731
        ax.plot(s["indice"].index, (s["indice"] - 1) * 100, color=C["blue"], lw=2.2,
                label=f"Cartera (TWR): {fin(s['indice'])}%", zorder=5)
        cols = [C["orange"], C["aqua"], C["yellow"]]
        for (nombre, b), col in zip(s["bms"].items(), cols):
            ax.plot(b["indice"].index, (b["indice"] - 1) * 100, color=col, lw=1.3,
                    label=f"{nombres.get(nombre, nombre.capitalize())}: {fin(b['indice'])}%")
        ax.set_title("A · Rendimiento acumulado vs referencias"); ax.set_ylabel("%")
        ax.legend(fontsize=8, loc="upper left"); ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))

        ax = fig.add_subplot(gs[0, 1])
        pos = pd.DataFrame(rep["posiciones"]).set_index("id")
        pos = pos[(pos["peso"] > 0) | (pos["peso_objetivo"] > 0)].iloc[::-1]
        y = np.arange(len(pos))
        ax.barh(y, pos["peso_objetivo"] * 100, height=0.0, color="none")
        for i, (_, f) in enumerate(pos.iterrows()):
            lo, hi = (f["peso_objetivo"] * 100 - f["banda_pp"]), (f["peso_objetivo"] * 100 + f["banda_pp"])
            ax.plot([max(lo, 0), hi], [i, i], color=C["band"], lw=10, solid_capstyle="butt")
            ax.plot([f["peso_objetivo"] * 100] * 2, [i - 0.28, i + 0.28], color=C["ink2"], lw=1.2)
            col = C["red"] if f["fuera_de_banda"] else C["blue"]
            ax.plot(f["peso"] * 100, i, "o", ms=9, color=col, mec=C["surf"], mew=1.5)
            ax.annotate(f"{es(f['peso'] * 100)}%", (f["peso"] * 100, i), xytext=(0, 9), textcoords="offset points",
                        ha="center", fontsize=8, color=C["ink"])
        ax.set_yticks(y); ax.set_yticklabels([f"{i}\n{c}" for i, c in zip(pos.index, pos["categoria"])], fontsize=8)
        ax.set_xlabel("% de la cartera"); ax.set_ylim(-0.7, len(pos) - 0.3)
        ax.set_title("B · Peso actual vs objetivo (banda = tolerancia)")
        ax.plot([], [], "o", color=C["blue"], label="Dentro de la banda"); ax.plot([], [], "o", color=C["red"], label="Fuera de la banda")
        ax.plot([], [], color=C["ink2"], label="Objetivo"); ax.legend(fontsize=8, loc="lower right")

        ax = fig.add_subplot(gs[1, 0])
        ax.fill_between(s["dd"].index, s["dd"] * 100, 0, color=C["blue"], alpha=0.25, lw=0)
        ax.plot(s["dd"].index, s["dd"] * 100, color=C["blue"], lw=1.4)
        ax.axhline(-self.lim["drawdown_alerta"] * 100, color=C["red"], ls="--", lw=0.9)
        ax.text(s["dd"].index[0], -self.lim["drawdown_alerta"] * 100 + 0.3, "umbral de alerta", fontsize=8, color=C["ink2"])
        ax.set_title(f"C · Caída desde el máximo (máx.: {es(rep['riesgo']['max_drawdown'] * 100)}%)")
        ax.set_ylabel("%"); ax.set_ylim(min(-self.lim["drawdown_alerta"] * 100 * 1.4, s["dd"].min() * 120), 0.5)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))

        ax = fig.add_subplot(gs[1, 1])
        hoy = self.fecha
        filas = [f for f in rep["posiciones"] if f["cantidad"] > 0]
        for i, f in enumerate(filas):
            if nn(f["dias_hasta_uso"]) is not None:
                fu = hoy + pd.Timedelta(days=f["dias_hasta_uso"])
                ax.plot(fu, i, marker="v", ms=10, color=C["ink"], ls="none")
            if nn(f["dias_hasta_vencimiento"]) is not None:
                fv = hoy + pd.Timedelta(days=f["dias_hasta_vencimiento"])
                mal = nn(f["dias_hasta_uso"]) is not None and f["dias_hasta_vencimiento"] > f["dias_hasta_uso"]
                ax.plot([hoy, fv], [i, i], color=C["red"] if mal else C["aqua"], lw=5, solid_capstyle="butt")
        for k, h in enumerate(rep["calce_caja"]["huecos"]):
            ax.axvline(pd.Timestamp(h["fecha"]), color=C["orange"], lw=1.2, ls="--")
            ax.text(pd.Timestamp(h["fecha"]), len(filas) - 0.35 - 0.45 * k, f" {es(h['monto'] / 1e6)} M",
                    fontsize=7.5, color=C["ink"], va="top")
        ax.axvline(hoy, color=C["ink2"], lw=0.8)
        ax.set_yticks(range(len(filas))); ax.set_yticklabels([f["id"] for f in filas], fontsize=8)
        ax.set_ylim(-0.7, len(filas) - 0.2)
        ax.plot([], [], color=C["aqua"], lw=5, label="Hasta el vencimiento (calza)")
        ax.plot([], [], color=C["red"], lw=5, label="Vence después de cuando se necesita")
        ax.plot([], [], marker="v", color=C["ink"], ls="none", label="Fecha en que se necesita la plata")
        ax.plot([], [], color=C["orange"], ls="--", lw=1.2, label="Hueco de caja proyectado")
        ax.legend(fontsize=7.5, loc="lower right"); ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))
        ax.set_title("D · Calce: vencimientos vs fecha de uso")
        r = rep["rendimiento"]
        fig.suptitle(f"Seguimiento de cartera al {hoy:%d/%m/%Y} · valor {self.base} {es(rep['valor_total'] / 1e6, 2)} M · "
                     f"TWR {es(r['twr'] * 100)}% · {len(rep['alertas'])} alertas",
                     x=0.01, ha="left", fontsize=14, fontweight="bold", color=C["ink"])
        fig.text(0.01, 0.005, self.cfg.get("fuente", "Cartera y precios provistos por el usuario. Cálculos propios. ORCA"),
                 fontsize=7.5, color=C["ink2"])
        fig.savefig(ruta, dpi=150, bbox_inches="tight"); plt.close(fig)


# ================================================================ self-test con resultados conocidos
def selftest():
    fechas = pd.bdate_range("2026-01-02", periods=253)
    # Activo que rinde 10% exacto en el período; aporte a mitad de camino.
    nivel = np.linspace(100, 110, len(fechas))
    precios = pd.DataFrame({"fecha": fechas, "activo": "A", "precio": nivel})
    medio = fechas[126]
    cfg = {"moneda_base": "ARS", "posiciones": [{"id": "A", "categoria": "Acción", "emisor": "X", "peso_objetivo": 1.0}],
           "movimientos": [{"fecha": str(fechas[0].date()), "activo": "A", "tipo": "compra", "cantidad": 10, "precio": 100},
                           {"fecha": str(medio.date()), "activo": "A", "tipo": "compra", "cantidad": 100,
                            "precio": float(nivel[126])}]}
    rep = Cartera(cfg, precios).reporte()
    ok_twr = abs(rep["rendimiento"]["twr"] - 0.10) < 1e-9
    # TIR: verificación independiente con la fórmula de valor presente
    tir = rep["rendimiento"]["tir_anual_mwr"]
    t1 = (medio - fechas[0]).days / 365; T = (fechas[-1] - fechas[0]).days / 365
    vpn = -1000 - 100 * nivel[126] / (1 + tir) ** t1 + 110 * 110 / (1 + tir) ** T
    # Cupón: un bono que no cambia de precio y paga 5 → TWR = 5% y la TIR coincide con la tasa del cupón
    precios_b = pd.DataFrame({"fecha": fechas, "activo": "B", "precio": 100.0})
    cfg_b = {"moneda_base": "ARS", "posiciones": [{"id": "B", "tipo": "bono", "categoria": "ON en dólares", "emisor": "Y",
                                                   "peso_objetivo": 1.0}],
             "movimientos": [{"fecha": str(fechas[0].date()), "activo": "B", "tipo": "compra", "cantidad": 1000, "precio": 100},
                             {"fecha": str(fechas[-1].date()), "activo": "B", "tipo": "cupon", "monto": 50}]}
    rb = Cartera(cfg_b, precios_b).reporte()
    return {"twr_esperado_10pct": ok_twr, "twr": rep["rendimiento"]["twr"],
            "tir_cumple_vpn_cero": bool(abs(vpn) < 1e-4 * 1000), "tir": tir,
            "cupon_twr_5pct": abs(rb["rendimiento"]["twr"] - 0.05) < 1e-9, "twr_bono": rb["rendimiento"]["twr"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cartera"); ap.add_argument("--precios"); ap.add_argument("--caja")
    ap.add_argument("--fecha"); ap.add_argument("--grafico"); ap.add_argument("--salida")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        print(json.dumps(selftest(), indent=2, ensure_ascii=False)); return
    if not (a.cartera and a.precios):
        ap.error("Indicá --cartera y --precios (o --selftest)")
    cfg = json.load(open(a.cartera, encoding="utf-8"))
    caja = json.load(open(a.caja, encoding="utf-8")) if a.caja else None
    c = Cartera(cfg, pd.read_csv(a.precios), a.fecha, caja)
    rep = c.reporte()
    if a.grafico:
        c.grafico(rep, a.grafico)
    txt = json.dumps(rep, indent=2, ensure_ascii=False, default=str)
    if a.salida:
        open(a.salida, "w", encoding="utf-8").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
