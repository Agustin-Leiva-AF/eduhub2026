#!/usr/bin/env python3
"""
Capa cuantitativa del Analista Researcher:
GJR-GARCH(1,1,1) con t asimétrica (por defecto) o t de Student + simulación Monte Carlo + validación estadística.

Uso:
  python montecarlo_gjr.py --csv precios.csv [--horizontes 21,63,252] [--sims 10000]
  python montecarlo_gjr.py --selftest      # verifica que el estimador recupera parámetros conocidos

El CSV debe tener una columna de fecha y una de cierre (close, adj close, adj_close, precio o cierre).
Usar precios AJUSTADOS por dividendos y splits. Salida: JSON por stdout.

Requiere: pip install arch statsmodels scipy pandas numpy
"""
import argparse
import json
import sys

import numpy as np
import pandas as pd
from arch import arch_model
from scipy import stats
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
import statsmodels.api as sm

MIN_OBS = 500        # ~2 años de ruedas: por debajo no se estima
OBS_RECOMENDADAS = 750
ALPHA_TEST = 0.05      # umbral de "reserva"
ALPHA_CRITICO = 0.01   # umbral de rechazo
DIAS_ANIO = 252
DIST_DEFECTO = "skewt"   # t asimétrica de Hansen: colas gordas + caídas más probables que subas


# ---------------------------------------------------------------- datos
def cargar_precios(path):
    df = pd.read_csv(path)
    cols = {c.lower().strip(): c for c in df.columns}
    col_fecha = next((cols[c] for c in ("date", "fecha", "timestamp") if c in cols), df.columns[0])
    # Prioridad al precio AJUSTADO (dividendos y splits); el cierre sin ajustar subestima el retorno.
    col_px = next((cols[c] for c in ("adjusted close", "adjusted_close", "adj close", "adj_close", "adjclose",
                                     "close", "cierre", "precio") if c in cols), None)
    if col_px is None:
        sys.exit("No encontré la columna de precio (close / adj close / cierre / precio).")
    s = pd.Series(df[col_px].astype(float).values, index=pd.to_datetime(df[col_fecha])).sort_index()
    return s[s > 0].dropna()


def log_retornos_pct(precios):
    return (100 * np.log(precios).diff()).dropna()


# ---------------------------------------------------------------- tests
def t_std_ppf(q, nu):
    """Cuantil de una t de Student estandarizada (varianza 1)."""
    return stats.t.ppf(q, nu) * np.sqrt((nu - 2) / nu)


def sign_bias_test(z):
    """Engle-Ng (1993): ¿queda asimetría sin capturar en los residuos estandarizados?"""
    z = np.asarray(z)
    y = z[1:] ** 2
    zl = z[:-1]
    neg = (zl < 0).astype(float)
    X = sm.add_constant(np.column_stack([neg, neg * zl, (1 - neg) * zl]))
    ols = sm.OLS(y, X).fit()
    f = ols.f_test(np.eye(4)[1:])
    return float(np.squeeze(f.pvalue))


def kupiec_pof(fallas, n, p):
    """Test de cobertura incondicional: ¿la tasa de excepciones coincide con la esperada?"""
    x = fallas
    if x == 0:
        lr = -2 * n * np.log(1 - p)
    elif x == n:
        lr = -2 * n * np.log(p)
    else:
        phat = x / n
        lr = -2 * ((n - x) * np.log(1 - p) + x * np.log(p) - (n - x) * np.log(1 - phat) - x * np.log(phat))
    return float(1 - stats.chi2.cdf(lr, 1))


def christoffersen_ind(hits):
    """Test de independencia: ¿las excepciones vienen en racimos?"""
    h = np.asarray(hits, dtype=int)
    a, b = h[:-1], h[1:]
    n00 = np.sum((a == 0) & (b == 0)); n01 = np.sum((a == 0) & (b == 1))
    n10 = np.sum((a == 1) & (b == 0)); n11 = np.sum((a == 1) & (b == 1))
    if n01 + n11 == 0 or (n00 + n01) == 0 or (n10 + n11) == 0:
        return None
    pi0 = n01 / (n00 + n01); pi1 = n11 / (n10 + n11); pi = (n01 + n11) / (n00 + n01 + n10 + n11)

    def ll(p, k0, k1):
        return (k0 * np.log(1 - p) if p < 1 else 0) + (k1 * np.log(p) if p > 0 else 0)

    lr = -2 * (ll(pi, n00 + n10, n01 + n11) - ll(pi0, n00, n01) - ll(pi1, n10, n11))
    return float(1 - stats.chi2.cdf(lr, 1))


# ---------------------------------------------------------------- modelo
def ajustar(r, o=1, last_obs=None, dist=DIST_DEFECTO):
    am = arch_model(r, mean="Constant", vol="GARCH", p=1, o=o, q=1, dist=dist)
    return am, am.fit(disp="off", last_obs=last_obs)


def ppf_innov(res):
    """Función cuantil de las innovaciones estandarizadas del modelo ajustado (normal, t o skew-t)."""
    d = res.model.distribution
    dp = res.params[d.parameter_names()].values if d.parameter_names() else None
    return lambda u: d.ppf(u, dp)


def kappa_negativo(res, n=200_000):
    """E[z² · 1(z<0)]: peso de los shocks negativos. Vale 0,5 si la distribución es simétrica."""
    u = (np.arange(n) + 0.5) / n
    z = ppf_innov(res)(u)
    return float(np.mean(z ** 2 * (z < 0)))


def backtest_var(r, frac_train=0.7, niveles=(0.95, 0.99), h_banda=21, dist=DIST_DEFECTO):
    """Estima con el 70% inicial y evalúa el VaR a 1 período fuera de muestra con parámetros fijos."""
    split = r.index[int(len(r) * frac_train)]
    _, res = ajustar(r, last_obs=split, dist=dist)
    fc = res.forecast(start=split, horizon=1, reindex=False)
    # La fila con fecha t es el pronóstico hecho al cierre de t para la rueda t+1:
    # se compara con el retorno SIGUIENTE (sin esto, el test usa información del futuro).
    sigma = np.sqrt(fc.variance.iloc[:, 0])
    real = r.shift(-1).loc[sigma.index]
    validos = real.notna()
    sigma, real = sigma[validos], real[validos]
    mu, q_fn = res.params["mu"], ppf_innov(res)
    out = {}
    for nivel in niveles:
        p = 1 - nivel
        var = -(mu + sigma * float(q_fn(p)))        # pérdida positiva en %
        hits = (real < -var).astype(int)
        n, x = len(hits), int(hits.sum())
        out[f"var_{int(nivel*100)}"] = {
            "observaciones": n,
            "excepciones": x,
            "esperadas": round(n * p, 1),
            "tasa_observada": round(x / n, 4),
            "p_kupiec": round(kupiec_pof(x, n, p), 4),
            "p_christoffersen": (None if (pc := christoffersen_ind(hits.values)) is None else round(pc, 4)),
        }
    out["montecarlo_banda"] = backtest_montecarlo(r, res, fc.variance.iloc[:, 0], H=h_banda)
    return out


def simular_gjr(params, sigma2_sig, H, sims, rng, ppf_fn=None):
    """Simula H períodos de un GJR-GARCH partiendo de la varianza ya conocida para el período siguiente.
    ppf_fn: cuantil de las innovaciones estandarizadas (ppf_innov(res)); si falta, se asume t con params['nu']."""
    mu, om, a, g, b = (params[k] for k in ("mu", "omega", "alpha[1]", "gamma[1]", "beta[1]"))
    if ppf_fn is None:
        nu = params["nu"]
        ppf_fn = lambda u: t_std_ppf(u, nu)  # noqa: E731
    s2 = np.full(sims, sigma2_sig)
    acum = np.zeros(sims)
    for _ in range(H):
        e = np.sqrt(s2) * ppf_fn(rng.uniform(size=sims))
        acum += mu + e
        s2 = om + (a + g * (e < 0)) * e ** 2 + b * s2
    return acum / 100                                        # retorno log acumulado


def backtest_montecarlo(r, res, var_sig, H=21, sims=2000, seed=0):
    """¿El rango 5%–95% del Monte Carlo contiene ~90% de los resultados reales a H ruedas?
    Ventanas sin superposición, parámetros fijos estimados solo con datos previos."""
    rng = np.random.default_rng(seed)
    pos = {d: i for i, d in enumerate(r.index)}
    debajo = arriba = n = 0
    origenes = var_sig.index[::H]
    q_fn = ppf_innov(res)
    for t in origenes:
        i = pos[t]
        if i + H >= len(r):
            break
        sim = simular_gjr(res.params, var_sig.loc[t], H, sims, rng, q_fn)
        real = r.iloc[i + 1:i + 1 + H].sum() / 100
        lo, hi = np.quantile(sim, [0.05, 0.95])
        debajo += real < lo
        arriba += real > hi
        n += 1
    fuera = debajo + arriba
    p = stats.binomtest(int(fuera), n, 0.10).pvalue if n else None
    return {"horizonte": H, "ventanas": n, "debajo_p5": int(debajo), "arriba_p95": int(arriba),
            "fuera_de_banda": int(fuera), "esperadas_fuera": round(n * 0.10, 1),
            "p_binomial": (round(float(p), 4) if p is not None else None),
            "nota": "Con pocas ventanas el test tiene poca potencia; se usa como chequeo de reserva."}


def simular(res, horizontes, sims, metodo, seed):
    H = max(horizontes)
    np.random.seed(seed)                                     # reproducibilidad
    fc = res.forecast(horizon=H, method=metodo, simulations=sims, reindex=False)
    caminos = fc.simulations.values[-1]                      # (sims, H) en % log
    acumulado = np.cumsum(caminos, axis=1) / 100
    resultado = {}
    for h in horizontes:
        ret = np.expm1(acumulado[:, h - 1])                  # retorno simple acumulado
        q05 = np.quantile(ret, 0.05)
        resultado[f"{h}_periodos"] = {
            "percentiles": {k: round(float(np.quantile(ret, v)), 4)
                            for k, v in (("p5", .05), ("p25", .25), ("p50", .5), ("p75", .75), ("p95", .95))},
            "prob_perder": round(float(np.mean(ret < 0)), 4),
            "prob_perder_mas_10pct": round(float(np.mean(ret < -0.10)), 4),
            "prob_perder_mas_20pct": round(float(np.mean(ret < -0.20)), 4),
            "var_95": round(float(-q05), 4),
            "es_95": round(float(-ret[ret <= q05].mean()), 4),
        }
    return resultado


def analizar(r, horizontes, sims, metodo, seed, periodos_anio=DIAS_ANIO, h_banda=21, dist=DIST_DEFECTO):
    n = len(r)
    if n < MIN_OBS:
        return {"error": f"Hay {n} retornos; se necesitan al menos {MIN_OBS} (~2 años de ruedas)."}
    avisos = []
    if n < OBS_RECOMENDADAS:
        avisos.append(f"Muestra corta ({n} ruedas): estimación inestable, usar con cautela.")

    _, res = ajustar(r, o=1, dist=dist)
    _, res_sym = ajustar(r, o=0, dist=dist)
    alternativa = "t" if dist == "skewt" else "skewt"
    _, res_alt = ajustar(r, o=1, dist=alternativa)
    p = res.params
    pv = res.pvalues
    kappa = kappa_negativo(res)
    persist = p["alpha[1]"] + p["beta[1]"] + p["gamma[1]"] * kappa
    z = (res.std_resid).dropna()

    lr = 2 * (res.loglikelihood - res_sym.loglikelihood)
    p_lr = float(1 - stats.chi2.cdf(lr, 1))

    var_lp = p["omega"] / (1 - persist) if persist < 1 else np.nan
    vol_lp = float(np.sqrt(var_lp * periodos_anio)) / 100 if persist < 1 else None
    vol_hoy = float(np.sqrt(res.forecast(horizon=1, reindex=False).variance.iloc[-1, 0] * periodos_anio)) / 100
    # Referencia del régimen: la mediana histórica de la volatilidad condicional (robusta).
    # La volatilidad de largo plazo implícita en el modelo queda mal identificada cuando la persistencia es alta.
    vol_tipica = float(np.median(res.conditional_volatility) * np.sqrt(periodos_anio)) / 100
    vol_muestral = float(r.std() * np.sqrt(periodos_anio)) / 100

    lb_z = acorr_ljungbox(z, lags=[10], return_df=True)["lb_pvalue"].iloc[0]
    lb_z2 = acorr_ljungbox(z ** 2, lags=[10], return_df=True)["lb_pvalue"].iloc[0]
    arch_lm = het_arch(z, nlags=5)[1]
    sb = sign_bias_test(z)
    bt = backtest_var(r, h_banda=h_banda, dist=dist)

    # ------------- veredicto
    # Se corren varios tests a la vez: si todos usaran 5%, un modelo correcto fallaría alguno
    # con frecuencia. Regla: p < 1% en un test crítico = NO VALIDADO; p entre 1% y 5% = reserva.
    pc95 = bt["var_95"]["p_christoffersen"]
    pvals = {
        "sin_arch_remanente": min(lb_z2, arch_lm),
        "sin_asimetria_remanente": sb,
        "var95_cobertura_ok": bt["var_95"]["p_kupiec"],
        "var99_cobertura_ok": bt["var_99"]["p_kupiec"],
        "var95_independencia_ok": 1.0 if pc95 is None else pc95,
        "montecarlo_cobertura_ok": (1.0 if bt["montecarlo_banda"]["p_binomial"] is None
                                    else bt["montecarlo_banda"]["p_binomial"]),
    }
    checks = {
        "parametros_validos": bool(p["omega"] > 0 and p["alpha[1]"] >= 0 and p["beta[1]"] >= 0
                                   and p["alpha[1]"] + p["gamma[1]"] >= 0),
        "estacionario": bool(persist < 1),
        **{k: bool(v > ALPHA_TEST) for k, v in pvals.items()},
    }
    criticos = ("sin_arch_remanente", "var95_cobertura_ok", "var99_cobertura_ok")
    falla_critica = (not checks["parametros_validos"] or not checks["estacionario"]
                     or any(pvals[c] < ALPHA_CRITICO for c in criticos))
    if falla_critica:
        veredicto = "NO VALIDADO"
    elif all(checks.values()):
        veredicto = "VALIDADO"
    else:
        veredicto = "VALIDADO CON RESERVAS"
    if persist >= 0.99:
        avisos.append("Persistencia muy alta (>=0,99): los shocks de volatilidad casi no se disipan; "
                      "la volatilidad de largo plazo es poco confiable.")
    gl = p.get("nu", p.get("eta"))
    if gl is not None and gl > 30:
        avisos.append("Grados de libertad > 30: las colas son casi normales.")
    if res_alt.bic < res.bic - 2:
        avisos.append(f"La distribución '{alternativa}' ajusta mejor por BIC; conviene re-correr con --dist {alternativa}.")
    if vol_lp and abs(vol_lp / vol_muestral - 1) > 0.3:
        avisos.append(f"La volatilidad de largo plazo que implica el modelo ({vol_lp:.1%}) difiere mucho de la "
                      f"histórica ({vol_muestral:.1%}): la volatilidad tiende a converger a un nivel poco confiable; "
                      "las bandas de horizontes largos pueden salir demasiado anchas.")
    if lb_z < ALPHA_TEST:
        avisos.append("Autocorrelación en los retornos estandarizados: la media constante puede quedarse corta.")

    out = {
        "muestra": {"periodos": n, "periodos_por_anio": periodos_anio, "desde": str(r.index[0].date()), "hasta": str(r.index[-1].date())},
        "modelo": f"GJR-GARCH(1,1,1), media constante, innovaciones {dist}",
        "distribucion": {"usada": dist, "bic": round(float(res.bic), 2),
                         "alternativa": alternativa, "bic_alternativa": round(float(res_alt.bic), 2),
                         "peso_shocks_negativos_kappa": round(kappa, 4)},
        "parametros": {k: round(float(v), 5) for k, v in p.items()},
        "p_values": {k: round(float(v), 4) for k, v in pv.items()},
        "persistencia": round(float(persist), 4),
        "vida_media_shock_periodos": (round(float(np.log(0.5) / np.log(persist)), 1) if 0 < persist < 1 else None),
        "volatilidad_anual_hoy": round(vol_hoy, 4),
        "volatilidad_anual_tipica": round(vol_tipica, 4),
        "volatilidad_anual_muestral": round(vol_muestral, 4),
        "volatilidad_anual_largo_plazo_modelo": (round(vol_lp, 4) if vol_lp else None),
        "regimen_volatilidad": ("alta" if vol_hoy > 1.25 * vol_tipica else
                                "baja" if vol_hoy < 0.8 * vol_tipica else "normal"),
        "asimetria": {
            "gamma": round(float(p["gamma[1]"]), 5),
            "p_gamma": round(float(pv["gamma[1]"]), 4),
            "lr_vs_garch_simetrico_p": round(p_lr, 4),
            "aic_gjr": round(float(res.aic), 2), "aic_garch": round(float(res_sym.aic), 2),
            "bic_gjr": round(float(res.bic), 2), "bic_garch": round(float(res_sym.bic), 2),
            "efecto_apalancamiento_significativo": bool(pv["gamma[1]"] < ALPHA_TEST and p["gamma[1]"] > 0),
        },
        "diagnostico_residuos": {
            "ljung_box_z_lag10_p": round(float(lb_z), 4),
            "ljung_box_z2_lag10_p": round(float(lb_z2), 4),
            "arch_lm_lag5_p": round(float(arch_lm), 4),
            "sign_bias_engle_ng_p": round(float(sb), 4),
        },
        "backtest_var_1d_fuera_de_muestra": bt,
        "checks": checks,
        "veredicto": veredicto,
        "avisos": avisos,
        "montecarlo": {"metodo": metodo, "simulaciones": sims,
                       "horizontes": simular(res, horizontes, sims, metodo, seed)},
    }
    return out


# ---------------------------------------------------------------- self-test
def selftest(seed=7):
    verdaderos = {"mu": 0.05, "omega": 0.02, "alpha[1]": 0.04, "gamma[1]": 0.10, "beta[1]": 0.88, "nu": 7.0}
    am = arch_model(None, mean="Constant", vol="GARCH", p=1, o=1, q=1, dist="t")
    sim = am.simulate(list(verdaderos.values()), nobs=4000, burn=500,
                      initial_value=None, x=None)
    r = pd.Series(sim["data"].values, index=pd.bdate_range("2010-01-01", periods=len(sim)))
    _, res = ajustar(r, dist="t")          # recuperación de parámetros con la distribución verdadera
    est = res.params
    tolerancias = {"mu": 0.03, "omega": 0.02, "alpha[1]": 0.04, "gamma[1]": 0.06, "beta[1]": 0.04, "nu": 3.0}
    filas, ok = [], True
    for k, v in verdaderos.items():
        dentro = abs(est[k] - v) <= tolerancias[k]
        ok &= dentro
        filas.append({"param": k, "verdadero": v, "estimado": round(float(est[k]), 4), "ok": bool(dentro)})
    reporte = analizar(r, [21, 63], 5000, "simulation", seed)   # pipeline completo con la distribución por defecto
    return {"recupera_parametros": bool(ok), "detalle": filas,
            "veredicto_sobre_serie_simulada": reporte["veredicto"], "checks": reporte["checks"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv")
    ap.add_argument("--horizontes", default="21,63,252", help="en ruedas (21≈1 mes, 63≈3 meses, 252≈1 año)")
    ap.add_argument("--sims", type=int, default=10000)
    ap.add_argument("--metodo", choices=["simulation", "bootstrap"], default="simulation",
                    help="simulation = innovaciones de la distribución del modelo; bootstrap = remuestreo de residuos (FHS)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--periodos-anio", type=int, default=DIAS_ANIO, help="252 diario, 52 semanal")
    ap.add_argument("--dist", choices=["skewt", "t", "normal"], default=DIST_DEFECTO)
    ap.add_argument("--h-banda", type=int, default=21, help="horizonte del backtest de la banda 5-95")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    np.random.seed(a.seed)
    if a.selftest:
        print(json.dumps(selftest(), indent=2, ensure_ascii=False))
        return
    if not a.csv:
        ap.error("Indicá --csv o --selftest")
    r = log_retornos_pct(cargar_precios(a.csv))
    hz = [int(h) for h in a.horizontes.split(",")]
    print(json.dumps(analizar(r, hz, a.sims, a.metodo, a.seed, a.periodos_anio, a.h_banda, a.dist), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
