#!/usr/bin/env python3
"""
Genera una cartera FICTICIA para probar el seguimiento: la pyme de demo (gastronomía en Córdoba)
invierte sus excedentes en mayo de 2026. Precios simulados; nombres de instrumentos genéricos.
Salida: cartera.json, precios.csv y caja.json en esta carpeta.
"""
import json
import os

import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(2026)
f = pd.bdate_range("2026-05-04", "2026-10-30")
n = len(f)
t = np.arange(n) / 252

# Referencias (índices de nivel)
caucion = 100 * (1 + 0.30 / 365) ** ((f - f[0]).days.values)                   # caución a 30% TNA
ipc_mensual = 0.022
ipc = 100 * (1 + ipc_mensual) ** ((f - f[0]).days.values / 30.4)
fx = 1450 * np.exp(0.012 * (f - f[0]).days.values / 30.4 + np.cumsum(rng.normal(0, 0.006, n)) - 0)  # ARS por USD

# Activos
fci_mm = 1000 * (1 + 0.28 / 365) ** ((f - f[0]).days.values)                  # cuotaparte FCI money market
venc_lecap = pd.Timestamp("2026-12-30")
dias_lecap = (venc_lecap - f).days.values
tir_lecap = 0.32 + np.cumsum(rng.normal(0, 0.002, n))                          # TIR de mercado que se mueve
lecap = 100 * 1.21 / (1 + tir_lecap) ** (dias_lecap / 365)                     # paga 121 al vencimiento
cer = 100 * (ipc / ipc[0]) * np.exp(np.cumsum(rng.normal(0.0001, 0.004, n)))   # ajusta por inflación + ruido real
on_usd = 98 + np.cumsum(rng.normal(0.004, 0.18, n))                            # USD por 100 VN
# CEDEAR (ARS) = subyacente en USD × tipo de cambio / ratio; con una corrección en septiembre
ret = rng.normal(0.0006, 0.011, n); ret[(f >= "2026-09-01") & (f <= "2026-09-25")] -= 0.009
subyacente = 650 * np.exp(np.cumsum(ret))
cedear = subyacente * fx / 20
# El cupón de la ON corta el precio el día de pago (cotiza ex-cupón)
pago = f.get_indexer([pd.Timestamp("2026-09-15")], method="bfill")[0]
on_usd[pago:] -= 3.5

precios = []
for nombre, serie in {"FCI_MM": fci_mm, "LETRA_A": lecap, "CER_B": cer, "ON_C": on_usd, "CEDEAR_D": cedear,
                      "FX_USD": fx, "BM_CAUCION": caucion, "BM_IPC": ipc}.items():
    precios += [{"fecha": str(d.date()), "activo": nombre, "precio": round(float(v), 6)} for d, v in zip(f, serie)]
# Simula un dato que dejó de llegar: la ON no tiene precio la última semana
precios = [p for p in precios if not (p["activo"] == "ON_C" and p["fecha"] > "2026-10-23")]
pd.DataFrame(precios).to_csv(os.path.join(AQUI, "precios.csv"), index=False)

p = pd.DataFrame(precios).pivot(index="fecha", columns="activo", values="precio")


def px(activo, dia):
    return float(p.loc[dia, activo])


d0, d1, d2, d3 = "2026-05-04", "2026-08-03", "2026-09-15", "2026-10-01"
cartera = {
    "nombre": "Excedentes de la pyme demo (FICTICIA)",
    "moneda_base": "ARS", "perfil": "moderado",
    "fuente": "Cartera y precios FICTICIOS generados para la demo. Cálculos propios. ORCA",
    "benchmarks": {"caucion": "BM_CAUCION", "inflacion": "BM_IPC", "dolar": "FX_USD"},
    "limites": {"banda_absoluta_pp": 5, "banda_relativa": 0.25, "concentracion_emisor_max": 0.30,
                "drawdown_alerta": 0.05, "dias_aviso_uso": 30},
    "posiciones": [
        {"id": "FCI_MM", "categoria": "FCI money market", "moneda": "ARS", "emisor": "FCI administradora 1",
         "peso_objetivo": 0.25, "liquidez_dias": 0, "se_necesita_el": "2026-12-18", "uso_futuro": "aguinaldo"},
        {"id": "LETRA_A", "tipo": "bono", "categoria": "Letra tasa fija", "moneda": "ARS", "emisor": "Tesoro Nacional",
         "peso_objetivo": 0.25, "liquidez_dias": 1, "vencimiento": "2026-12-30", "se_necesita_el": "2026-12-20",
         "duration_modificada": 0.15, "uso_futuro": "vacaciones y cargas de diciembre"},
        {"id": "CER_B", "tipo": "bono", "categoria": "Bono CER", "moneda": "ARS", "emisor": "Tesoro Nacional",
         "peso_objetivo": 0.20, "liquidez_dias": 1, "vencimiento": "2027-06-30", "se_necesita_el": "2027-07-15",
         "duration_modificada": 0.65, "uso_futuro": "aguinaldo de junio 2027"},
        {"id": "ON_C", "tipo": "bono", "categoria": "ON en dólares", "moneda": "USD", "emisor": "Empresa energética 1",
         "peso_objetivo": 0.15, "liquidez_dias": 1, "vencimiento": "2027-09-15", "se_necesita_el": "2027-10-01",
         "duration_modificada": 0.85, "uso_futuro": "cambio de equipamiento de cocina"},
        {"id": "CEDEAR_D", "categoria": "CEDEAR", "moneda": "ARS", "emisor": "Índice S&P 500 (vía CEDEAR)",
         "peso_objetivo": 0.15, "liquidez_dias": 1, "se_necesita_el": "2027-12-31", "uso_futuro": "excedente estructural"},
    ],
    "movimientos": [],
}
# Compras iniciales por $50 M según el objetivo
total0 = 50_000_000
for pos in cartera["posiciones"]:
    a = pos["id"]; monto = total0 * pos["peso_objetivo"]
    precio = px(a, d0)
    factor = 0.01 if pos.get("tipo") == "bono" else 1.0
    fxv = px("FX_USD", d0) if pos["moneda"] == "USD" else 1.0
    cartera["movimientos"].append({"fecha": d0, "activo": a, "tipo": "compra",
                                   "cantidad": round(monto / (precio * factor * fxv), 2), "precio": precio})
# Aporte de agosto: $8 M más al FCI (excedente de la temporada de invierno)
cartera["movimientos"].append({"fecha": d1, "activo": "FCI_MM", "tipo": "compra",
                               "cantidad": round(8_000_000 / px("FCI_MM", d1), 2), "precio": px("FCI_MM", d1)})
# Cupón de la ON: 3,5 USD por cada 100 VN
vn_on = cartera["movimientos"][3]["cantidad"]
cartera["movimientos"].append({"fecha": d2, "activo": "ON_C", "tipo": "cupon", "monto": round(vn_on * 0.035, 2)})
# Rescate de octubre: $9 M del FCI para cubrir un pago de proveedores
cartera["movimientos"].append({"fecha": d3, "activo": "FCI_MM", "tipo": "venta",
                               "cantidad": round(9_000_000 / px("FCI_MM", d3), 2), "precio": px("FCI_MM", d3)})
json.dump(cartera, open(os.path.join(AQUI, "cartera.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)

caja = {"fecha_corte": "2026-10-30",
        "huecos_proyectados": [{"fecha": "2026-11-20", "monto": 6_000_000, "motivo": "pago de proveedores + servicios"},
                               {"fecha": "2026-12-18", "monto": 14_000_000, "motivo": "aguinaldo y sueldos"}]}
json.dump(caja, open(os.path.join(AQUI, "caja.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("ok:", len(precios), "precios;", len(cartera["movimientos"]), "movimientos")
