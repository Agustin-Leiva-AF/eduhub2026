# Referencia inicial: Argentina — snapshot al 31/10/2026

## Propósito y advertencia

Este documento transcribe y organiza el material macroeconómico y político aportado por el usuario. No constituye una base de series temporales ni una verificación independiente. Los valores deben conservar su período, fuente y condición. Las menciones a medios o consultoras se conservan como atribuciones del material original; no se proporcionaron enlaces ni fichas metodológicas completas.

**No usar estos datos como valores actuales después del 31/10/2026 sin actualización.** Para pronósticos cuantitativos se necesitan series históricas consistentes, no solo este corte transversal.

## A. Factor económico

### A.1 Estabilización y actividad

- Inflación: septiembre de 2026, 1,9% mensual; 23,6% acumulado en 2026; 33,4% interanual.
- El material indica que septiembre aceleró frente al 1,7% de agosto.
- Inflación mayorista: 3,2% en septiembre, presentada como posible presión de costos.
- REM: expectativa de 30,3% interanual para fin de 2026.
- **Inconsistencia textual:** aparece otra línea que dice “la inflación de septiembre fue de 19 y acumula un alza de 236”. Por contexto podría ser una omisión de separadores decimales, pero no debe corregirse automáticamente. Confirmar contra la publicación original.
- PBI: el material informa +2% interanual en el segundo trimestre y -0,6% frente al trimestre previo. Otra línea resume que “el PBI cayó 0,6% en el segundo trimestre y solo aumentaron las exportaciones”. Mantener separadas las variaciones interanual y trimestral.
- EMAE: agosto, -1,7% interanual y +0,1% mensual, tras caída en julio. El material plantea riesgo de recesión técnica si el tercer trimestre vuelve a caer; esto es una hipótesis condicional, no una confirmación.
- Desempleo: 7,9% en el segundo trimestre de 2026, descrito en el material como máximo desde 2021.
- Informalidad: aproximadamente 6,1 millones de personas con empleo informal; 348.000 más que un año antes.

### A.2 Cambiario y financiero

- Dólar oficial: $1.550 al 26/10/2026.
- Riesgo país: 707 puntos al 26/10; el material agrega que cerró octubre cerca de 787 puntos, 30% más que en septiembre. Se atribuye presión a tasas del Tesoro de EE.UU. superiores al 5%.
- Reservas: superiores a US$50.000 millones. El material no aclara si son brutas o netas; no inferirlo.
- Tasas de descubierto para empresas de primera línea: bajaron de 28% a 26% en julio. El material advierte que una pyme común paga más; no informa tasa representativa para pymes.
- Crédito en pesos: volvió a caer en agosto.
- Las cifras de dólar y riesgo país tienen fechas específicas y no deben presentarse sin fecha.

### A.3 Mora y crédito

- Mora total del sistema: 7,75% en agosto; descrita como estable en los cuatro meses anteriores.
- Comparación histórica indicada: octubre de 2024, 1,5% total (2,5% familias y 0,7% empresas). Verificar definiciones y comparabilidad antes de calcular variaciones.
- Mora de familias: 12,81% en agosto.
- Tarjetas: el material menciona 1,6% en octubre de 2024 y 13,1% en mayo de 2026.
- Mora de empresas: 3,6% en julio y 3,8% en agosto.
- Septiembre: dato privado atribuido a consultora 1816, no oficial del BCRA al momento del documento. Mora familiar 12,20%; mora empresarial 3,82%. Refinanciaciones: 3,9% del crédito a familias y 0,9% del crédito a empresas.
- Formulación sugerida por el material: “baja la mora de familias, pero no la de empresas”. Mantener la atribución privada y la fecha de corte.

### A.4 Cheques rechazados y pagos

- Marzo de 2026: cerca de 112.000 cheques rechazados por falta de fondos, frente a 55.000 un año antes; tasa de rechazo 2,2% en cantidad y 1,6% en monto.
- Julio: 1,9% en cantidad y 1,2% en monto, 0,1 punto porcentual menos que junio.
- Abril: rechazos todavía 60% por encima de 2025.
- El material atribuye a un directivo de Fidelitas la evaluación de que los rechazos seguían en niveles récord, con mora empresarial elevada y crédito restringido.
- ECHEQ: 64,6% de los cheques en cantidad y 86,3% en monto; ECHEQ en dólares compensaron US$41,1 millones en julio.
- El documento indica que julio era el último dato mensual encontrado y recomienda comprobar si el BCRA publicó agosto.

### A.5 Pymes y actividad comercial

- Ventas minoristas CAME: +0,3% interanual en septiembre; -1,2% frente a agosto; -2,1% acumulado en el año.
- 44,3% de los dueños consultados indicó que su situación empeoró frente al año anterior.
- CEPA: entre noviembre de 2023 y junio de 2026 se habrían perdido 31.268 empresas y 181.542 empleos; 83,4% de los cierres corresponderían a microempresas. El propio material advierte que CEPA tiene una mirada crítica del Gobierno y sugiere contrastar con SIPA o CAME.
- Producción de pymes industriales: caída de 26,9% en el segundo trimestre frente a 2023, según el material.
- Se mencionan presiones de caja por el pago del aguinaldo y costos asociados.

### A.6 Narrativa económica del material

El material propone la siguiente cadena interpretativa para un pitch de una solución de gestión de tesorería:
1. Ventas planas y costos mayoristas acelerando presionan la caja.
2. Mora empresarial y cheques rechazados reflejan tensión en la cadena de pagos.
3. Crédito caro o escaso aumenta el valor de gestionar la liquidez propia.
4. Con inflación mensual cercana al 2%, mantener excedentes ociosos implica pérdida de poder adquisitivo.
5. La digitalización del ECHEQ puede facilitar automatización de cobros y pagos.
6. La regulación de endosos y operatoria de ALyC puede afectar la triangulación de fondos y las alternativas de inversión de excedentes.

Esta secuencia es una hipótesis de análisis y de propuesta comercial, no una relación causal demostrada.

## B. Factor político y regulatorio

### B.1 ECHEQ, ALyC e impuesto al cheque

- El material afirma que en mayo de 2026 la CNV liberó el límite de endosos de ECHEQ y permitió a ALyC operar fondos mediante ellos.
- Se describe una controversia con bancos y una posible preocupación de ARCA por el efecto sobre el impuesto al cheque.
- Septiembre de 2026: el material afirma que la CNV dio de baja esa operatoria mediante RG 1166 y eliminó el cheque como medio de cobro y pago con comitentes para ALyC.
- El material atribuye la marcha atrás a presión del Ministerio de Economía y a la caída de la recaudación del impuesto al cheque. Esta atribución requiere verificación.
- Se menciona una regla en análisis entre BCRA y CNV para permitir transferencias desde cuentas bancarias hacia ALyC o FCI destinadas a inversiones en mercado de capitales sin volver a pagar impuesto al cheque. El documento la identifica expresamente como proyecto, no norma vigente.
- Implicancia propuesta: el costo tributario de mover fondos podría afectar el modelo de inversión de excedentes de corto plazo.

### B.2 Política tributaria

- Impuesto al cheque: el material indica que continuaba vigente, con alícuota de 1,2% según una nota citada. Verificar alícuota, base, exenciones y tratamiento aplicable antes de cualquier cálculo.
- Reforma tributaria amplia: se describe como postergada por restricciones fiscales.
- Ingresos Brutos: se menciona una percepción del 3% a pymes, con fondos retenidos por el fisco durante 30 días. Verificar jurisdicción, régimen y alcance; no generalizar a todas las pymes.
- ARCA: se menciona un reclamo de la UIA en agosto de 2026 para suspender embargos a pymes.

### B.3 Reforma laboral y política pyme

- El material afirma que el Congreso aprobó una reforma laboral a comienzos de 2026.
- Menciona el RIMI con exenciones para inversiones desde US$150.000 para mipymes. Verificar texto, umbrales, beneficiarios y vigencia.
- Se describen posiciones contrapuestas: el Gobierno destaca formalización y beneficios para pymes; representantes pymes cuestionan alcance y señalan debilidad del consumo interno.
- El material menciona una suspensión judicial en primera instancia de artículos clave; verificar tribunal, artículos, alcance y estado procesal.
- Apertura de importaciones: se describe como política del Gobierno y fuente de preocupación para parte de la industria y CAME.
- Financiamiento: CAME habría planteado que solo una de cada tres pymes accede a financiamiento.

### B.4 Contexto político y electoral

- El material ubica las elecciones presidenciales en octubre de 2027.
- Menciona debate sobre PASO y reforma electoral, negociaciones por Presupuesto 2027 y acuerdos con gobernadores.
- Incluye una encuesta con 31,7% para Milei y 27,9% para el peronismo; es una sola medición y no debe tratarse como pronóstico electoral ni consenso.
- Hipótesis del material: el año electoral puede aumentar incertidumbre regulatoria y volatilidad cambiaria y financiera.

## C. Aplicación al análisis de tesorería de pymes

Para consultas sobre una solución que automatice cobros, pagos y colocación de excedentes:
- medir el costo de mantener saldos líquidos frente a inflación y alternativas de corto plazo;
- considerar calendario de pagos, aguinaldo, impuestos, percepciones y vencimientos;
- estimar riesgo de cobro con mora, refinanciaciones y cheques rechazados, sin equiparar indicadores de universos distintos;
- comparar costo de crédito efectivamente accesible a pymes, no solo tasas de primera línea;
- incorporar comisiones, impuestos, plazos de liquidación, riesgo de mercado y liquidez de FCI/Lecap;
- validar siempre el marco normativo vigente para ECHEQ, ALyC, bancos, FCI e impuesto al cheque.

## D. Datos adicionales necesarios para pronósticos cuantitativos

Este snapshot no permite estimar por sí solo modelos econométricos confiables. Solicitar, idealmente en CSV o Excel, series históricas con fecha y valor:
- IPC general, núcleo y mayorista: mensual.
- EMAE: mensual; PBI: trimestral, con serie desestacionalizada y original.
- Tipo de cambio oficial y financieros: diaria o mensual, especificando referencia.
- Tasas de política, plazo fijo, préstamos y descubiertos: diaria o mensual y tipo de tasa.
- Reservas, base monetaria, M2 y depósitos: diaria o mensual, con definiciones.
- Resultado fiscal, ingresos y gasto: mensual.
- Exportaciones, importaciones y saldo comercial: mensual.
- Empleo, desempleo, salarios e informalidad: frecuencia original de publicación.
- Mora familiar y empresarial, crédito y cheques rechazados: mensual, con definiciones.
- Expectativas REM: cada relevamiento y horizonte.
- Series internacionales relevantes: tasas del Tesoro de EE.UU., precios de commodities y actividad de socios comerciales.

Para cada serie: fuente, unidad, frecuencia, fecha de publicación, revisiones, metodología y enlace. No combinar series con definiciones distintas sin documentarlo.
